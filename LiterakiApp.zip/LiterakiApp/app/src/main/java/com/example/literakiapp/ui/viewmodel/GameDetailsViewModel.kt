package com.example.literakiapp.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.literakiapp.data.model.ApiGame
import com.example.literakiapp.data.model.ApiTilePlacement
import com.example.literakiapp.data.repository.AppException
import com.example.literakiapp.data.repository.LiterakiRepository
import com.example.literakiapp.data.repository.SessionExpiredException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class GameDetailsUiState(
    val currentUserId: Int? = null,
    val game: ApiGame? = null,
    val isLoading: Boolean = true,
    val isSubmittingMove: Boolean = false,
    val isStartingGame: Boolean = false,
    val draftTiles: Map<String, String> = emptyMap(),
    val errorMessage: String? = null,
    val sessionExpired: Boolean = false
)

class GameDetailsViewModel(
    private val repository: LiterakiRepository,
    private val gameId: Int
) : ViewModel() {
    private val _uiState = MutableStateFlow(GameDetailsUiState())
    val uiState: StateFlow<GameDetailsUiState> = _uiState.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null, sessionExpired = false) }
            try {
                val currentUser = repository.getCurrentUser()
                val game = repository.getGame(gameId)
                _uiState.update {
                    it.copy(
                        currentUserId = currentUser.id,
                        game = game,
                        draftTiles = sanitizeDraftTiles(game.board, it.draftTiles),
                        isLoading = false,
                        errorMessage = null,
                        sessionExpired = false
                    )
                }
            } catch (exception: SessionExpiredException) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        errorMessage = exception.message,
                        sessionExpired = true
                    )
                }
            } catch (exception: AppException) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        errorMessage = exception.message
                    )
                }
            }
        }
    }

    fun startGame() {
        if (uiState.value.isStartingGame) return

        viewModelScope.launch {
            _uiState.update { it.copy(isStartingGame = true, errorMessage = null, sessionExpired = false) }
            try {
                val game = repository.startGame(gameId)
                _uiState.update {
                    it.copy(
                        game = game,
                        draftTiles = emptyMap(),
                        isStartingGame = false,
                        errorMessage = null
                    )
                }
            } catch (exception: SessionExpiredException) {
                _uiState.update {
                    it.copy(
                        isStartingGame = false,
                        errorMessage = exception.message,
                        sessionExpired = true
                    )
                }
            } catch (exception: AppException) {
                _uiState.update {
                    it.copy(
                        isStartingGame = false,
                        errorMessage = exception.message
                    )
                }
            }
        }
    }

    fun onDraftTileChanged(x: Int, y: Int, value: String) {
        val key = boardCellKey(x, y)
        val normalizedValue = normalizeDraftLetter(value)

        _uiState.update {
            if (it.game?.board?.containsKey(key) == true) {
                it
            } else {
                val updatedDraftTiles = it.draftTiles.toMutableMap().apply {
                    if (normalizedValue.isBlank()) {
                        remove(key)
                    } else {
                        put(key, normalizedValue)
                    }
                }

                it.copy(
                    draftTiles = updatedDraftTiles,
                    errorMessage = null
                )
            }
        }
    }

    fun clearDraftTiles() {
        _uiState.update {
            it.copy(
                draftTiles = emptyMap(),
                errorMessage = null
            )
        }
    }

    fun passTurn() {
        submitGameAction { repository.passTurn(gameId) }
    }

    fun resignGame() {
        submitGameAction { repository.resignGame(gameId) }
    }

    fun placeTiles() {
        val state = uiState.value
        val tiles = buildTilePlacements(state.draftTiles)

        if (tiles.isEmpty()) {
            _uiState.update { it.copy(errorMessage = "Wpisz co najmniej jedną literę bezpośrednio na planszy.") }
            return
        }

        val myRack = state.game
            ?.players
            ?.firstOrNull { it.id == state.currentUserId }
            ?.rack
            .orEmpty()

        if (!rackContainsAllLetters(myRack, tiles.map(ApiTilePlacement::letter))) {
            _uiState.update { it.copy(errorMessage = "Szkic używa liter, których nie ma aktualnie w Twoim racku.") }
            return
        }

        submitGameAction {
            repository.placeTiles(gameId, tiles)
        }
    }

    private fun submitGameAction(action: suspend () -> ApiGame) {
        if (uiState.value.isSubmittingMove) return

        viewModelScope.launch {
            _uiState.update { it.copy(isSubmittingMove = true, errorMessage = null, sessionExpired = false) }
            try {
                val currentUser = repository.getCurrentUser()
                val game = action()
                _uiState.update {
                    it.copy(
                        currentUserId = currentUser.id,
                        game = game,
                        draftTiles = emptyMap(),
                        isLoading = false,
                        isSubmittingMove = false,
                        errorMessage = null
                    )
                }
            } catch (exception: SessionExpiredException) {
                _uiState.update {
                    it.copy(
                        isSubmittingMove = false,
                        errorMessage = exception.message,
                        sessionExpired = true
                    )
                }
            } catch (exception: AppException) {
                _uiState.update {
                    it.copy(
                        isSubmittingMove = false,
                        errorMessage = exception.message
                    )
                }
            }
        }
    }

    companion object {
        fun factory(
            repository: LiterakiRepository,
            gameId: Int
        ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return GameDetailsViewModel(repository, gameId) as T
            }
        }
    }
}

