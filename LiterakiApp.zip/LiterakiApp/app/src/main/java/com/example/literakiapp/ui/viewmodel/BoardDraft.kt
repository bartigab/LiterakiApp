package com.example.literakiapp.ui.viewmodel

import com.example.literakiapp.data.model.ApiTilePlacement

const val BOARD_SIZE = 15

fun boardCellKey(x: Int, y: Int): String = "$x,$y"

fun normalizeDraftLetter(value: String): String = value.uppercase().filter(Char::isLetter).take(1)

fun sanitizeDraftTiles(
    board: Map<String, String>,
    draftTiles: Map<String, String>
): Map<String, String> = draftTiles
    .mapNotNull { (key, value) ->
        val normalizedValue = normalizeDraftLetter(value)
        val coordinates = parseBoardCellKey(key) ?: return@mapNotNull null

        when {
            board.containsKey(key) -> null
            coordinates.first !in 0 until BOARD_SIZE -> null
            coordinates.second !in 0 until BOARD_SIZE -> null
            normalizedValue.isBlank() -> null
            else -> key to normalizedValue
        }
    }
    .toMap()

fun buildTilePlacements(draftTiles: Map<String, String>): List<ApiTilePlacement> = draftTiles
    .mapNotNull { (key, value) ->
        val normalizedValue = normalizeDraftLetter(value)
        val coordinates = parseBoardCellKey(key) ?: return@mapNotNull null

        if (normalizedValue.isBlank()) {
            null
        } else {
            ApiTilePlacement(
                letter = normalizedValue,
                x = coordinates.first,
                y = coordinates.second
            )
        }
    }
    .sortedWith(compareBy<ApiTilePlacement> { it.y }.thenBy { it.x })

fun rackContainsAllLetters(rack: List<String>, letters: Collection<String>): Boolean {
    val rackCounts = rack
        .map(::normalizeDraftLetter)
        .filter(String::isNotBlank)
        .groupingBy { it }
        .eachCount()
        .toMutableMap()

    letters
        .map(::normalizeDraftLetter)
        .filter(String::isNotBlank)
        .forEach { letter ->
            val remaining = rackCounts[letter] ?: return false
            if (remaining <= 0) {
                return false
            }
            rackCounts[letter] = remaining - 1
        }

    return true
}

private fun parseBoardCellKey(key: String): Pair<Int, Int>? {
    val parts = key.split(',')
    if (parts.size != 2) return null

    val x = parts[0].toIntOrNull() ?: return null
    val y = parts[1].toIntOrNull() ?: return null
    return x to y
}
