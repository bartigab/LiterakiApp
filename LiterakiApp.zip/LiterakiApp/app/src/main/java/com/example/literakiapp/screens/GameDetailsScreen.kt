package com.example.literakiapp.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.literakiapp.data.model.ApiGame
import com.example.literakiapp.data.model.ApiMove
import com.example.literakiapp.data.model.ApiPlayer
import com.example.literakiapp.ui.viewmodel.BOARD_SIZE
import com.example.literakiapp.ui.viewmodel.GameDetailsUiState
import com.example.literakiapp.ui.viewmodel.boardCellKey

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameDetailsScreen(
    uiState: GameDetailsUiState,
    onRefresh: () -> Unit,
    onStartGame: () -> Unit,
    onPassTurn: () -> Unit,
    onResignGame: () -> Unit,
    onTileChanged: (Int, Int, String) -> Unit,
    onClearDraft: () -> Unit,
    onPlaceTiles: () -> Unit,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Szczegóły gry") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Wróć")
                    }
                },
                actions = {
                    IconButton(onClick = onRefresh) {
                        Icon(
                            Icons.Filled.Refresh,
                            contentDescription = "Odśwież",
                            tint = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { padding ->
        when {
            uiState.isLoading -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            }

            uiState.errorMessage != null && uiState.game == null -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = uiState.errorMessage,
                        color = MaterialTheme.colorScheme.error,
                        textAlign = TextAlign.Center
                    )
                }
            }

            uiState.game != null -> {
                val game = uiState.game
                val myPlayer = game.players.firstOrNull { it.id == uiState.currentUserId }
                val isMyTurn = game.currentTurnUserId == uiState.currentUserId
                val canStart = game.status == "waiting" && game.players.size == 2 && !uiState.isStartingGame
                val canPlay = game.status == "active" && isMyTurn && !uiState.isSubmittingMove

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item { GameHeaderCard(game = game) }

                    item {
                        StatusCard(
                            game = game,
                            isStartingGame = uiState.isStartingGame,
                            currentUserId = uiState.currentUserId,
                            onStartGame = onStartGame,
                            canStart = canStart
                        )
                    }

                    item {
                        PlayersCard(
                            players = game.players,
                            currentUserId = uiState.currentUserId
                        )
                    }

                    if (!myPlayer?.rack.isNullOrEmpty()) {
                        item { RackCard(player = myPlayer!!) }
                    }

                    if (game.status == "active") {
                        item {
                            TurnActionsCard(
                                isMyTurn = isMyTurn,
                                isSubmittingMove = uiState.isSubmittingMove,
                                placedTilesCount = uiState.draftTiles.size,
                                onClearDraft = onClearDraft,
                                onPlaceTiles = onPlaceTiles,
                                onPassTurn = onPassTurn,
                                onResignGame = onResignGame,
                                canPlay = canPlay
                            )
                        }
                    }

                    item {
                        BoardCard(
                            board = game.board,
                            draftTiles = uiState.draftTiles,
                            canEdit = canPlay,
                            onTileChanged = onTileChanged
                        )
                    }
                    item { MovesCard(moves = game.moves) }

                    if (uiState.errorMessage != null) {
                        item {
                            Text(
                                text = uiState.errorMessage,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GameHeaderCard(game: ApiGame) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.secondaryContainer
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Gra #${game.id}",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSecondaryContainer
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Kod dołączenia: ${game.id}",
                color = MaterialTheme.colorScheme.onSecondaryContainer
            )
            Text(
                text = "Status: ${game.status}",
                color = MaterialTheme.colorScheme.onSecondaryContainer
            )
        }
    }
}

@Composable
private fun StatusCard(
    game: ApiGame,
    isStartingGame: Boolean,
    currentUserId: Int?,
    onStartGame: () -> Unit,
    canStart: Boolean
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = when (game.status) {
                    "waiting" -> "Lobby oczekuje na graczy"
                    "active" -> "Gra aktywna"
                    "finished" -> "Gra zakończona"
                    else -> "Status: ${game.status}"
                },
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            when {
                game.status == "waiting" && game.players.size < 2 -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Schedule, contentDescription = null)
                        Spacer(modifier = Modifier.size(8.dp))
                        Text("Czekamy na drugiego gracza. Przekaż kod lobby: ${game.id}")
                    }
                }

                game.status == "waiting" && game.players.size == 2 -> {
                    Text("Lobby jest gotowe. Możesz wystartować grę z backendu.")
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = onStartGame,
                        enabled = canStart,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (isStartingGame) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                        } else {
                            Icon(Icons.Filled.PlayArrow, contentDescription = null)
                            Spacer(modifier = Modifier.size(8.dp))
                            Text("Start gry")
                        }
                    }
                }

                game.status == "active" -> {
                    val currentPlayerName = game.players.firstOrNull { it.id == game.currentTurnUserId }?.username ?: "-"
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.CheckCircle, contentDescription = null)
                        Spacer(modifier = Modifier.size(8.dp))
                        Text("Tura gracza: ${if (game.currentTurnUserId == currentUserId) "Ty" else currentPlayerName}")
                    }
                }

                game.status == "finished" -> {
                    val winnerName = game.players.firstOrNull { it.id == game.winnerId }?.username ?: "brak"
                    Text("Gra zakończona. Zwycięzca: $winnerName")
                }

                else -> {
                    Text("Możesz odświeżyć ekran, aby zobaczyć najnowszy stan backendu.")
                }
            }
        }
    }
}

@Composable
private fun PlayersCard(players: List<ApiPlayer>, currentUserId: Int?) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Gracze",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
            Spacer(modifier = Modifier.height(12.dp))
            players.forEach { player ->
                Text(
                    text = buildString {
                        append(if (player.id == currentUserId) "Ty" else player.username)
                        append(" • punkty: ${player.score}")
                        append(" • pozycja: ${player.position}")
                    }
                )
                Spacer(modifier = Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun RackCard(player: ApiPlayer) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Twój rack",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = player.rack?.joinToString("  ") ?: "Brak liter",
                fontSize = 20.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
private fun TurnActionsCard(
    isMyTurn: Boolean,
    isSubmittingMove: Boolean,
    placedTilesCount: Int,
    onClearDraft: () -> Unit,
    onPlaceTiles: () -> Unit,
    onPassTurn: () -> Unit,
    onResignGame: () -> Unit,
    canPlay: Boolean
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Akcje w grze",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = if (isMyTurn) {
                    "To Twoja tura. Wpisuj litery bezpośrednio w puste pola planszy, a potem zatwierdź ruch."
                } else {
                    "Czekasz na ruch przeciwnika. Plansza pozostaje tylko do podglądu do czasu Twojej tury."
                },
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = if (placedTilesCount == 0) {
                    "Szkic ruchu jest pusty."
                } else {
                    "Szkic ruchu: $placedTilesCount pól gotowych do wysłania."
                },
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = onPlaceTiles,
                modifier = Modifier.fillMaxWidth(),
                enabled = canPlay && placedTilesCount > 0
            ) {
                if (isSubmittingMove) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                } else {
                    Text("Zatwierdź litery z planszy")
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            FilledTonalButton(
                onClick = onClearDraft,
                modifier = Modifier.fillMaxWidth(),
                enabled = canPlay && placedTilesCount > 0
            ) {
                Text("Wyczyść szkic z planszy")
            }

            Spacer(modifier = Modifier.height(10.dp))

            FilledTonalButton(
                onClick = onPassTurn,
                modifier = Modifier.fillMaxWidth(),
                enabled = canPlay
            ) {
                Text("Pomiń turę")
            }

            Spacer(modifier = Modifier.height(10.dp))

            FilledTonalButton(
                onClick = onResignGame,
                modifier = Modifier.fillMaxWidth(),
                enabled = canPlay,
                colors = ButtonDefaults.filledTonalButtonColors()
            ) {
                Icon(Icons.Filled.Close, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Poddaj grę")
            }
        }
    }
}

@Composable
private fun BoardCard(
    board: Map<String, String>,
    draftTiles: Map<String, String>,
    canEdit: Boolean,
    onTileChanged: (Int, Int, String) -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Plansza",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = if (canEdit) {
                    "Kliknij puste pole i wpisz jedną literę. Zajęte pola z backendu są zablokowane do edycji."
                } else if (board.isEmpty()) {
                    "Plansza jest jeszcze pusta — środek został oznaczony gwiazdką."
                } else {
                    "Aktualny stan planszy 15×15. Litery pochodzą bezpośrednio z API."
                },
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(modifier = Modifier.horizontalScroll(rememberScrollState())) {
                Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                    for (y in 0 until BOARD_SIZE) {
                        Row(horizontalArrangement = Arrangement.spacedBy(1.dp)) {
                            for (x in 0 until BOARD_SIZE) {
                                val key = boardCellKey(x, y)
                                BoardCell(
                                    x = x,
                                    y = y,
                                    placedLetter = board[key],
                                    draftLetter = draftTiles[key],
                                    isEditable = canEdit && !board.containsKey(key),
                                    onLetterChange = { onTileChanged(x, y, it) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BoardCell(
    x: Int,
    y: Int,
    placedLetter: String?,
    draftLetter: String?,
    isEditable: Boolean,
    onLetterChange: (String) -> Unit
) {
    val isCenter = x == 7 && y == 7
    val hasPlacedLetter = !placedLetter.isNullOrBlank()
    val hasDraftLetter = !draftLetter.isNullOrBlank()

    val backgroundColor = when {
        hasPlacedLetter -> MaterialTheme.colorScheme.primaryContainer
        hasDraftLetter -> MaterialTheme.colorScheme.secondaryContainer
        isCenter -> MaterialTheme.colorScheme.tertiaryContainer
        else -> MaterialTheme.colorScheme.surface
    }

    val contentColor = when {
        hasPlacedLetter -> MaterialTheme.colorScheme.onPrimaryContainer
        hasDraftLetter -> MaterialTheme.colorScheme.onSecondaryContainer
        isCenter -> MaterialTheme.colorScheme.onTertiaryContainer
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }

    Box(
        modifier = Modifier
            .size(32.dp)
            .clip(MaterialTheme.shapes.extraSmall)
            .background(backgroundColor)
            .border(
                width = 1.dp,
                color = if (isEditable) MaterialTheme.colorScheme.outline else MaterialTheme.colorScheme.outlineVariant,
                shape = MaterialTheme.shapes.extraSmall
            ),
        contentAlignment = Alignment.Center
    ) {
        when {
            hasPlacedLetter -> {
                Text(
                    text = placedLetter.orEmpty(),
                    color = contentColor,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }

            isEditable -> {
                BasicTextField(
                    value = draftLetter.orEmpty(),
                    onValueChange = onLetterChange,
                    singleLine = true,
                    textStyle = LocalTextStyle.current.copy(
                        color = contentColor,
                        fontSize = 13.sp,
                        fontWeight = if (hasDraftLetter) FontWeight.Bold else FontWeight.Medium,
                        textAlign = TextAlign.Center
                    ),
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.Characters,
                        keyboardType = KeyboardType.Text
                    ),
                    cursorBrush = SolidColor(contentColor),
                    modifier = Modifier.fillMaxSize(),
                    decorationBox = { innerTextField ->
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            if (!hasDraftLetter && isCenter) {
                                Text(
                                    text = "★",
                                    color = contentColor,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium,
                                    textAlign = TextAlign.Center
                                )
                            }
                            innerTextField()
                        }
                    }
                )
            }

            else -> {
                Text(
                    text = if (isCenter) "★" else "",
                    color = contentColor,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
private fun MovesCard(moves: List<ApiMove>) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Historia ruchów",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
            Spacer(modifier = Modifier.height(12.dp))

            if (moves.isEmpty()) {
                Text(
                    text = "Brak ruchów. To normalne dla nowego lobby albo świeżo rozpoczętej gry.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                moves.takeLast(10).reversed().forEach { move ->
                    val tilesDescription = if (move.tiles.isEmpty()) {
                        ""
                    } else {
                        move.tiles.joinToString(prefix = " • ") { tile ->
                            "${tile.letter}(${tile.x},${tile.y})"
                        }
                    }
                    Text("#${move.id} • ${move.moveType} • +${move.score} pkt$tilesDescription")
                    Spacer(modifier = Modifier.height(6.dp))
                }
            }
        }
    }
}
