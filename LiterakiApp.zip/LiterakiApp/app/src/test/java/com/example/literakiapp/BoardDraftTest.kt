package com.example.literakiapp

import com.example.literakiapp.ui.viewmodel.boardCellKey
import com.example.literakiapp.ui.viewmodel.buildTilePlacements
import com.example.literakiapp.ui.viewmodel.normalizeDraftLetter
import com.example.literakiapp.ui.viewmodel.rackContainsAllLetters
import com.example.literakiapp.ui.viewmodel.sanitizeDraftTiles
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BoardDraftTest {
    @Test
    fun normalizeDraftLetter_keepsOnlySingleUppercaseLetter() {
        assertEquals("Ą", normalizeDraftLetter("ąb1"))
        assertEquals("", normalizeDraftLetter("1?"))
    }

    @Test
    fun sanitizeDraftTiles_removesOccupiedOutOfRangeAndBlankEntries() {
        val sanitized = sanitizeDraftTiles(
            board = mapOf(boardCellKey(7, 7) to "K"),
            draftTiles = mapOf(
                boardCellKey(7, 7) to "a",
                boardCellKey(8, 7) to "o",
                boardCellKey(15, 7) to "t",
                "bad-key" to "z",
                boardCellKey(9, 7) to ""
            )
        )

        assertEquals(mapOf(boardCellKey(8, 7) to "O"), sanitized)
    }

    @Test
    fun buildTilePlacements_returnsSortedCoordinates() {
        val placements = buildTilePlacements(
            mapOf(
                boardCellKey(9, 7) to "t",
                boardCellKey(7, 7) to "k",
                boardCellKey(8, 7) to "o"
            )
        )

        assertEquals(listOf("K", "O", "T"), placements.map { it.letter })
        assertEquals(listOf(7, 8, 9), placements.map { it.x })
        assertEquals(listOf(7, 7, 7), placements.map { it.y })
    }

    @Test
    fun rackContainsAllLetters_checksLetterCounts() {
        assertTrue(rackContainsAllLetters(listOf("K", "O", "T"), listOf("K", "O")))
        assertFalse(rackContainsAllLetters(listOf("K", "O", "T"), listOf("K", "K")))
    }
}
